#ifndef EVENT_H
#define EVENT_H

#include "Date.h"

typedef struct{
    Date date;
    char* details;
}Event;

void displayEvent(Event * evnt);
void setEvent(Event* evnt, char* detail, Date * dt);

#endif
